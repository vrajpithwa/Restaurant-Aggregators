<?php
    $server = "localhost:3333";
    $user = "root";
    $password = "";
    $db = "db1";

    $conn = mysqli_connect($server,$user,$password,$db);
        
    if(!$conn)
    {
        echo 'Database Error: ' . mysqli_connect_error() ;
        exit;
    }

    $results=array();
    $sql = "SELECT * FROM orderlist";
    $result = mysqli_query($conn,$sql);
    while ($row = mysqli_fetch_array($result))
    { 
        $results[] = $row['orderlist'];
    }
    echo json_encode($results);
?>