-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3333:3333
-- Generation Time: Feb 08, 2023 at 08:34 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db1`
--

-- --------------------------------------------------------

--
-- Table structure for table `orderlist`
--

CREATE TABLE `orderlist` (
  `order_no` varchar(50) NOT NULL,
  `customer_name` varchar(50) NOT NULL,
  `order_details` varchar(200) NOT NULL,
  `amount` varchar(20) NOT NULL,
  `tax` varchar(5) NOT NULL,
  `final_amount` varchar(20) NOT NULL,
  `payment_status` varchar(10) NOT NULL,
  `date` varchar(10) NOT NULL,
  `time` varchar(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `platefromName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orderlist`
--

INSERT INTO `orderlist` (`order_no`, `customer_name`, `order_details`, `amount`, `tax`, `final_amount`, `payment_status`, `date`, `time`, `address`, `platefromName`) VALUES
('6545002765', 'Thomas Yates ', '1 Paneer Khadai\r\n', '190', '60', '250', 'Online', '10/07/2022', '01:32:27', 'Dr Yagnik Rd, Jheelwas, Sadar, Rajkot, Gujarat 360002, India', 'Zomato'),
('35344550321', 'Vishwam', '1 Kashmiri naan, 1 Tawa Paratha, 1 Panner Lucknowi', '420', '80', '500', 'Online', '10/07/2022', '12:24:40', 'St Kabir Rd, Near Sardar School, Mayur Nagar, Shakti Industrial Zone, Rajkot, Gujarat 360003, India', 'Swiggy'),
('6545002779', 'Keval', '1 Garlic Kulcha, 1 Mix Paratha, 1 Paneer Kadhai', '290', '40', '350', 'Online', '10/07/2022', '12:30:23', 'Riddhisiddhi Complex, Shop No. 105, Near Geeta Mandir Bkhaktinagar Circle, Rajkot, Gujarat 360001, I', 'Zomato'),
('6545002768', 'Mansi', '2 Patiyala Lassi', '170', '25', '195', 'Online', '10/07/2022', '12:33:45', 'Dr Yagnik Rd, Jheelwas, Sadar, Rajkot, Gujarat 360002, India', 'Zomato'),
('6545002774', 'Labhdi Ohara', '3 Garlic Naan, 1 Panner Kadhai', '300', '54', '354', 'Online', '10/07/2022', '12:44:03', '101,1st Floor, Omkareshvar Complex, Chudasamma Main Road, Near Raiya Road Railway Crossing, Shaw Nag', 'Swiggy'),
(' 53344558921', 'Keval Behera', '1 Veg Kadhai, 1 Panner Bhurji, 1 Steam Rice', '360', '50', '410', 'Online', '10/07/2022', '12:46:54', 'Near Central Bank of India, Jayraj Plot, Rajkot, Gujarat 360001, India', 'Swiggy'),
('89344550321', 'Huzefa Dhankot', '1 Chana Masala', '180', '20', '200', 'Online', '10/07/2022', '12:48:52', 'Opp Hotel Bizz, Dr Yagnik Rd, Rama Krishan Nagar, Rajkot, Gujarat 360001, India', 'Swiggy'),
('6545002765', 'Jefin', '1 Paneer Khadai', '300', '100', '400', 'Online', '02/03/2022', '12:21:43', '215-Lotus Arcade,Opp Satyavijay Ice-Cream, ,Rajkot, Gondal Rd, Rajkot, Gujarat 360001, India', 'Zomato'),
('6545002766', 'Vraj', '1 Panner Bhurji', '250', '50', '300', 'Online', '01/07/2022', '11:24:40', '22/39 New Jaganath, near Mahakali Temple Main Road, Rajkot, Gujarat 360001, India', 'Swiggy'),
('6545002767', 'Keval', '1 Mexican Sandwich', '655', '45', '700', 'Online', '04/09/2022', '10:25:45', 'Amrut Commercial Centre, 209, Sardar Nagar Main Rd, Rajkot, Gujarat 360001, India', 'Uber Eats'),
('6545002768', 'Shashank', '3 Laccha Paratha,  1 Veg Kadhai      ', '980', '120', '1100', 'Online', '10/23/2021', '12:30:23', 'Kanta Stree Vikas Gruh Road,Millpara, Bhakti Nagar,, Rajkot, Gujarat, Rajkot, Gujarat 360001, India', 'Uber Eats'),
('6545002769', 'Dev', '7 Mango Ice Cream', '170', '80', '250', 'Online', '02/09/2022', '09:43:45', 'Dr Yagnik Rd, Opp. Jagnath Temple, Sardarnagar, Rajkot, Gujarat 360001, India', 'Uber Eats'),
('6545002770', 'Arshdeep', '1 Kashmiri naan, 1 Tawa Paratha, 1 Panner Lucknowi', '900', '200', '1100', 'Online', '06/03/2022', '08:00:03', '302 - BUSINESS PARK, NR.PRINCESS SCHOOL, Kalavad Rd, opp. TVS JIVRAJANI SHOWROOM, Rajkot, 360005, In', 'Swiggy'),
('6545002778', 'Jyot', '1 Cheese Naan', '100', '20', '120', 'Online', '10/08/2022', '17:26:27', 'Riddhisiddhi Complex, Shop No. 105, Near Geeta Mandir Bkhaktinagar Circle, Rajkot, Gujarat 360001, I', 'Zomato'),
('6545002779', 'Vishwam', '15 Aloo Paratha, 1 Pineapple Raita', '1500', '250', '1750', 'Online', '05/09/2022', '16:24:40', 'Jain Steel Traders, 8, Lati Plot, C/o, Ranchhod Nagar, Rajkot, Gujarat 360003, India', 'Uber Eats'),
('6545002780', 'Sushant', '1 Tawa Paratha, 1 Paneer Toofani', '200', '100', '300', 'Online', '10/08/2022', '19:25:06', '405, Prasham Near Dharam Cinema, Kasturba Road, Kasturba Road, Rajkot, Gujarat 360001, India', 'Swiggy'),
('6545002781', 'Het', '1 Biryani, 1 Cheese masala papad', '600', '50', '650', 'Online', '01/19/2022', '20:30:23', 'Amardeep Complex, 401, Street Number 2, Rajputpara, Rajkot, Gujarat 360001, India', 'Uber Eats'),
('6545002782', 'Riya', '3 Laccha Paratha,  1 Veg Kadhai ', '500', '83', '583', 'Online', '04/25/2022', '22:33:45', '111-112, Amidhara, Canal Rd, Karanpara, Rajkot, Gujarat 360001, India', 'Uber Eats'),
('6545002783', 'Krisha', '5 Laccha Paratha,  1 Veg Kadhai ', '300', '60', '360', 'Online', '06/27/2022', '15:44:03', 'First Floor, Rameshwar Complex, Moti Tanki Chowk, Rajkot, Gujarat, India', 'Zomato');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`) VALUES
(0, 'admin', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
