<?php

$server = "localhost:3333";
$user = "root";
$password = "";
$db = "db1";

$conn = mysqli_connect($server,$user,$password,$db);

if(!$conn) {
    die("Connection Failed:".mysqli_connect_error());
}

?>