<?php
  $con = mysqli_connect("localhost:3333","root","","db1");
  if($con){
    echo "connected";
  }
  // $con = "SELECT * FROM orderlist";
  // $result = mysqli_query($conn, $sql);
?>
<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Date', 'Platform'],
         <?php
         $sql = "SELECT * FROM orderlist";
         $fire = mysqli_query($con,$sql);
          while ($result = mysqli_fetch_assoc($fire)) {
            echo"['".$result['date']."',".$result['platefromName']."],";
          }

         ?>
        ]); 

        var options = {
          title: 'Date and the Platform'
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }
    </script>
  </head>
  <body>
    <div id="piechart" style="width: 900px; height: 500px;"></div>
  </body>
</html>
