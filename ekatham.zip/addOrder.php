<?php
if (isset($_POST['submit']))
{

    $name = $_POST['user_name'];
    $plateform = $_POST['zom'];
    $address= $_POST['address']; 
    $menu = $_POST['spa'];
    $payment = $_POST['onl'];
    $orderNo=random_int(1000000000,9999999999);
    $servername = "localhost:3333";
    $username = "root";
    $password = "";
    $dbname = "db1";
    $today = date("m/d/20y"); 
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }
    $time = "8:01:30";  
    //$sql = "INSERT INTO `orderlist`(`order_no`, `customer_name`, `order_details`, `amount`,`tax`, `final_amount`, `payment_status` , `date`, `time`, `address`, `platefromName`) VALUES ($orderNo, $name, $menu,'300','36','336',$payment,date('mm/dd/20y'),$time,$address,$plateform)";
    

    $sql="INSERT INTO `orderlist` (`order_no`, `customer_name`, `order_details`, `amount`, `tax`, `final_amount`, `payment_status`, `date`, `time`, `address`, `platefromName`) VALUES ('$orderNo', '$name', '$menu', '200', '30', '230', '$payment', '$today', '$time', '$address', '$plateform')";
    if ($conn->query($sql) === TRUE)
     {
      echo "New record created successfully";
    } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
    }
}


?>

    <div class="main">
        <h1>Place Your Order Here!</h1>
            <legend><div class="number">1</div> Your Info:</legend>
            <legend><label for="name">Name:</label><br></legend>
        <form name="form" action="" method="post">
        <input type="text" id="name" name="user_name" value="" >
                
       <br>
        <legend>	
            <label for="mail">Platform</label></legend><br>
                <input type="radio" id="zomato" name="zom" value="zomato" ><label>Zomato</label>  
                <input type="radio" id="swiggy" name="zom" value="Swiggy" ><label>Swiggy</label>
                <input type="radio" id="uber eats" name="zom" value="Uber eats"><label>Uber Eats</label><br><br>
    
                <legend><label for="address">Address:</label><br></legend>
                <input type="text" id="address" name="address" value="" >
            <!-- <textarea><input type="text" id="address" name="address" ></textarea> -->
        
            <legend><div class="number">2</div> Menu:</legend>
            <input type="radio" id="spaghetti" name="spa" value = "spaghetti"><label>Spaghetti</label>
            <input type="radio" id="manchurian" name="spa" value="manchurian"><label>Manchurian</label>
            <input type="radio" id="pasta" name= "spa" value="pasta"><label>Pasta</label>
            <input type="radio" id="pizza" name="spa" value="pizza"><label>Pizza</label>

            <legend><div class="number">3</div> Payment:</legend>
            <input type="radio" id="online" name="onl" value = "online"><label>Online</label>
            <input type="radio" id="cash" name="onl" value ="cash"><label>Cash On Delivery</labelx>
            
        </fieldset>
    <input class="button" type="submit" name="submit" value="Give me Food!">
    
    </form>
    </div>
    <div class="order">
        <h1>Thanks for your order!</h1>
        <img src="https://i.imgur.com/O0oqbwc.jpg">
    </div>
    </div>
    