<?php
    $swiggy=0;
    $zomato = 0;
    $uber = 0;

    $sql="SELECT * FROM orderlist";
    $dev = "SELECT * FROM orderlist WHERE date > GETDATE()";


    // $sql = "SELECT * FROM orderlist ORDER BY date DESC";

        $result=$conn-> query($sql);
        
        if ($result-> num_rows > 0)
        {
            while ($row=$result-> fetch_assoc()) {
                if(strtolower($row['platefromName'])=="Zomato"){
                    $zomato=$zomato+1;
                }
            }
            while ($row=$result-> fetch_assoc()) {
                if(strtolower($row['platefromName'])=="Swiggy"){
                    $swiggy=$swiggy+1;
                }
            }
            while ($row=$result-> fetch_assoc()) {
                if(strtolower($row['platefromName'])=="Uber"){
                    $uber=$uber+1;
                }
            }

        }
        
    $dataPoints = array( 
        array("y" => $swiggy,"label" => "Swiggy" ),
        array("y" => $zomato,"label" => "Zomato" ),
        array("y" => $uber,"label" => "Uber" ),
        
    );
    
    ?>